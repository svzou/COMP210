package assn02;

public class ItemInfo {
    String _date;
    String _time;
    String _category;
    float _fee;
    int _quantity;
    float _totalTime;
    int _cost;




}
