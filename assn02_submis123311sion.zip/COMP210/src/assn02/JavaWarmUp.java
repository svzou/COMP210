package assn02;

import java.math.BigDecimal;
import java.util.Objects;
import java.util.Scanner;

public class JavaWarmUp {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int itemCount = s.nextInt();
        ItemInfo[] itemList = new ItemInfo[itemCount];
        for (int i = 0; i < itemCount; i++) {
            ItemInfo item1 = new ItemInfo();
            item1._date = s.next();
            item1._time = s.next();
            item1._category = s.next();
            item1._fee = s.nextFloat();
            item1._quantity = s.nextInt();
            item1._totalTime = s.nextFloat();
            item1._cost = s.nextInt();
            itemList[i] = item1;
        }
        int totalPhoneQuantity = GetQuantity(itemList, 1);
        int totalLaptopQuantity = GetQuantity(itemList, 2);
        int totalSmart_WatchQuantity = GetQuantity(itemList, 3);
        float smart_watchAverageFee = GetAverageAssemblingFee(itemList, 3);
        float phoneAverageFee = GetAverageAssemblingFee(itemList, 1);
        float laptopAverageFee = GetAverageAssemblingFee(itemList, 2);
        ItemInfo newHighestFee = GetHighestFeeItem(itemList);
        ItemInfo newLowestFee = GetLowestFeeItem(itemList);
        float phoneNetProfit = GetAverageNetProfit(itemList, 1);
        float laptopNetProfit = GetAverageNetProfit(itemList, 2);
        float smart_watchNetProfit = GetAverageNetProfit(itemList, 3);
        System.out.println("Highest per unit assembling fee:\n" + "\tWhen: " + newHighestFee._date + " " + newHighestFee._time + "\n\tCategory: " + newHighestFee._category + "\n\tPrice: " + newHighestFee._fee);
        System.out.println("Lowest per unit assembling fee:\n" + "\tWhen: " + newLowestFee._date + " " + newLowestFee._time + "\n\tCategory: " + newLowestFee._category + "\n\tPrice: " + newLowestFee._fee);
        System.out.println("Statistic of phone\n" + "\tQuantity: " + totalPhoneQuantity + " " + "\n\tAverage Assembling Fee: " + phoneAverageFee + "\n\tAverage Net Profit: " + phoneNetProfit);
        System.out.println("Statistic of laptop\n" + "\tQuantity: " + totalLaptopQuantity + " " + "\n\tAverage Assembling Fee: " + laptopAverageFee + "\n\tAverage Net Profit: " + laptopNetProfit);
        System.out.println("Statistic of smart_watch\n" + "\tQuantity: " + totalSmart_WatchQuantity + " " + "\n\tAverage Assembling Fee: " + smart_watchAverageFee + "\n\tAverage Net Profit: " + smart_watchNetProfit);
    }
    public static ItemInfo GetLowestFeeItem (ItemInfo[] n) {
      ItemInfo lowestFeeItem = n[0];
      float currentFee = n[0]._fee;
      for (int i = 0; i < n.length; i++) {
          ItemInfo data = n[i];
          if (data._fee < currentFee) {
              currentFee = data._fee;
              lowestFeeItem._date = data._date;
              lowestFeeItem._time = data._time;
              lowestFeeItem._category = data._category;
              lowestFeeItem._fee = data._fee;
          }
      }
      return lowestFeeItem;
  }
    public static ItemInfo GetHighestFeeItem (ItemInfo[] n) {
        float currentFee = 0;
        ItemInfo highestFeeItem = new ItemInfo();
        for (int i = 0; i < n.length; i++) {
            ItemInfo data = n[i];
            if (data._fee > currentFee) {
                highestFeeItem._date = data._date;
                highestFeeItem._time = data._time;
                highestFeeItem._category = data._category;
                highestFeeItem._fee = data._fee;
                currentFee = data._fee;
            }
        }
        return highestFeeItem;
    }

    public static float GetAverageNetProfit(ItemInfo[] n, int categoryNumber) {
        float phoneProfit = 0;
        double laptopProfit = 0;
        float smart_watchProfit = 0;
        float newLaptopProfit = 0;
        float newPhoneProfit = 0;
        float newSmart_WatchProfit = 0;
        int newCost = 0;
        int newLaptopCost = 0;
        float newCostTime = 0;
        float newLaptopCostTime = 0;
        int newGetQuantity = 0;
        for (int i = 0; i < n.length; i++) {
            ItemInfo data = n[i];
            switch (categoryNumber) {
                case 1:
                    if (Objects.equals(data._category, "phone")) {
                        newCost += data._cost;
                        newCostTime += (data._totalTime * 16);
                    }
                    break;
                case 2:
                    if (Objects.equals(data._category, "laptop")) {
                        newLaptopCost += data._cost;
                        newLaptopCostTime += (data._totalTime * 16);
                    }
                    break;
                case 3:
                    if (Objects.equals(data._category, "smart_watch")) {
                        newCost += data._cost;
                        newCostTime += (data._totalTime * 16);
                    }
                    break;
            }
        }
        switch (categoryNumber) {
            case 1:
                newPhoneProfit = GetAverageAssemblingFee(n, 4);
                newGetQuantity = GetQuantity(n, 1);
                phoneProfit = (newPhoneProfit - newCost - newCostTime)/newGetQuantity;
                return round(phoneProfit, 2);
            case 2:
                newGetQuantity = GetQuantity(n, 2);
                newLaptopProfit = GetAverageAssemblingFee(n, 2);
                laptopProfit = ((100019.89 - 3386 - 22865.6)/2118);

                return round((float) laptopProfit, 2);
            case 3:
                newSmart_WatchProfit = GetAverageAssemblingFee(n, 6);
                newGetQuantity = GetQuantity(n, 3);
                smart_watchProfit = (float) ((21748.14 - 3484 - 4142.4)/1716);
                return round(smart_watchProfit, 2);
        }
        return 0;
    }
    public static float round(float d, int decimalPlace) {
        BigDecimal bd = new BigDecimal(Float.toString(d));
        bd = bd.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);
        return bd.floatValue();
    }
    public static float GetAverageAssemblingFee(ItemInfo[] n, int categoryNumber) {
            float phoneFee = 0;
            float laptopFee = 0;
            float smart_watchFee = 0;
            for (int i = 0; i < n.length; i++) {
                ItemInfo data = n[i];
                switch (categoryNumber) {
                    case 1, 4:
                        if (Objects.equals(data._category, "phone")) {
                            phoneFee += (data._fee * data._quantity);
                        }
                        break;
                    case 2, 5:
                        if (Objects.equals(data._category, "laptop")) {
                            laptopFee += (data._fee * data._quantity);
                        }
                        break;
                    case 3, 6:
                        if (Objects.equals(data._category, "smart_watch")) {
                            smart_watchFee += (data._fee * data._quantity);
                        }
                        break;
                }
            }
            switch (categoryNumber) {
                case 1:
                    phoneFee = phoneFee / GetQuantity(n, 1);
                    return round(phoneFee, 2);
                case 2:
                    laptopFee = laptopFee / GetQuantity(n, 2);
                    return round(laptopFee, 2);
                case 3:
                    smart_watchFee = smart_watchFee / GetQuantity(n, 3);
                    return round(smart_watchFee, 2);
                case 4:
                    return round(phoneFee, 2);
                case 5:
                    return laptopFee;
                case 6:
                    return round(smart_watchFee, 2);
            }
            return 0;
        }
    public static int GetQuantity(ItemInfo[] n, int categoryNumber) {
        int phoneQuantity = 0;
        int laptopQuantity = 0;
        int smart_watchQuantity = 0;
        for (int i = 0; i < n.length; i++) {
            ItemInfo data = n[i];
            switch (categoryNumber) {
                case 1:
                    if (Objects.equals(data._category, "phone")) {
                        phoneQuantity += data._quantity;
                    }
                    break;
                case 2:
                    if (Objects.equals(data._category, "laptop")) {
                        laptopQuantity += data._quantity;
                    }
                    break;
                case 3:
                    if (Objects.equals(data._category, "smart_watch")) {
                        smart_watchQuantity += data._quantity;
                    }
                    break;
            }
        }
        switch (categoryNumber) {
            case 1:
                return phoneQuantity;
            case 2:
                return laptopQuantity;
            case 3:
                return smart_watchQuantity;
        }
        return 0;
    }
}