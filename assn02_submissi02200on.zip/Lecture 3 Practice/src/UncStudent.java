import java.util.Scanner;
public class UncStudent {
    String _fName;
    String _lName;
    int _id;
    String _admitTerm;

    public static void main(String[] args) {
        UncStudent st = new UncStudent();
        st._fName = "John";
        st._lName = "Carr";
        st._id = 333;
        System.out.println(st._fName + st._lName + st._id);
        Scanner s = new Scanner(System.in);
        System.out.println("Enter fname" + s.next() );
    }



}
